/*
    File:       lcdboard.cpp
    Version:    0.1.0
    Date:       Feb. 21, 2013
	License:	GPL v2
    
	atmega128 board code
    
    ****************************************************************************
    Copyright (C) 2013 Radu Motisan  <radu.motisan@gmail.com>

	http://www.pocketmagic.net

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
    ****************************************************************************
 */

#include <avr/io.h>
#include "timeout.h"
#include <util/delay.h>
#include "led.h"
#include "lcd/hd44780.h"
#include "uart/uart.h"

// atmega128 has two leds connected to PA0 and PA1
LED led1, led2;

//HD44780 lcd;
HD44780 lcd;
UART uart0;

#define RADDR 0x10 // common address parameter

// we can't know in which order we get the bytes of a package
// so we use a circular buffer with 3 positions
uint8_t buf[3], ind,  v;

ISR(USART_RXC_vect){
	volatile char c = UDR; //Read the value out of the UART buffer
	//v =c; // unpackaged byte
	// add the byte to the circular buffer
	buf[ind] = c;
	 
	// we don't know which is the first byte of our package, 
	// so we check the circular buffer, testing each byte for the start condition
	for (int i=0;i<3;i++) {
		uint8_t raddress, data, chk;//transmitter address
		raddress = buf[(0+i)%3];
		data = buf[(1+i)%3];
		chk = buf[(2+i)%3];
		if (chk == ((raddress + data)%256))
			v = data;
	}	
	// increment the circular buffer index
	ind = (ind + 1) %3;
}

int main(void)
{
	_delay_ms(200);
	uart0.Init(0, 1200, true);

	_delay_ms(200);
	// RS, E, D4,D5,D6,D7: default: lcd.lcd_init(&PORTD, PD3, &PORTD, PD4, &PORTD, PD5, &PORTD, PD6, &PORTD, PD7, &PORTB, PB0);
	lcd.lcd_init(&PORTD, PD3, &PORTD, PD4, &PORTD, PD5, &PORTD, PD6, &PORTD, PD7, &PORTB, PB0);

	// show logo, wait a little then go with the main loop
	lcd.lcd_cursor_home();
	lcd.lcd_string("pocketmagic.net   ");
	_delay_ms(500);
	
int i = 0;
while(1)
{
	i = (i+1)%256;
		
	lcd.lcd_cursor_home();
	lcd.lcd_string_format("idx:%d v:%d     \n2nd line  ", i, v);
	_delay_ms(100);
}
}