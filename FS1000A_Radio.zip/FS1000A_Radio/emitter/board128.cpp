/*
    File:       board128.cpp
    Version:    0.1.0
    Date:       Feb. 21, 2013
	License:	GPL v2
    
	atmega128 board code
    
    ****************************************************************************
    Copyright (C) 2013 Radu Motisan  <radu.motisan@gmail.com>

	http://www.pocketmagic.net

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
    ****************************************************************************
 */

#include <avr/io.h>
#include "timeout.h"
#include <util/delay.h>
#include "led.h"
#include "lcd/5110.h"
#include "uart/uart.h"

// atmega128 has two leds connected to PA0 and PA1
LED led1, led2;
LCD_5110 lcd;
UART uart0;

//define receive parameters
#define RADDR 0x10 // common address parameter

void Send_Packet(uint8_t addr, uint8_t cmd) {
	uart0.Send(addr);//send receiver address
	uart0.Send(cmd);//send increment command
	uart0.Send((addr+cmd) % 256 );//send checksum
}

int main(void)
{
	_delay_ms(999);
	// init serial link
	uart0.Init(0,1200, false); //uart0:
	
	// init leds
	led1.Init(&DDRA, &PORTA, 0); //DDRA, PORTA, PA0
	led2.Init(&DDRA, &PORTA, 1); //DDRA, PORTA, PA1
	led1.Set(0);led2.Set(1);
	//
	_delay_ms(100);
	lcd.init(&PORTB, PB0, &PORTB, PB1,
	&PORTB, PB2, &PORTB, PB3, &PORTB, PB4);
	
	
	
	int i = 0;
while(1)
{
	i = (i+1) % 256;
	led1.Toggle();
	led2.Toggle();
	Send_Packet(RADDR, i); // send packaged byte
	//uart0.Send(i); //send unpackaged byte
	lcd.goto_xy(0,0);
	lcd.send_format_string("%d ", i);
	_delay_ms(1000);

}
}